class Personagem {
  String nome;
  String descricao;
  String imagem;

  Personagem(this.nome, this.descricao, this.imagem);
}
